# movieinfo-website
Movie Database website written using HTML, CSS, JS &amp; PHP.

University Project - Year I

NSBM - LK

Module: Web Based Application Development
